﻿using Answers.FirstExercise;
using System;

namespace Consola
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
