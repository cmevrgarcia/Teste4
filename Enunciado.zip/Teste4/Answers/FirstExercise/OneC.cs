﻿using System;

namespace Answers
{
    public class OneC
    {
        
    }

}
