﻿using System;

namespace Answers
{
    public static class OneB
    {
       
    }

  
}
