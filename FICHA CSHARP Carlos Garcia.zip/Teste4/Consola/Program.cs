﻿using Answers;
using Answers.FirstExercise;
using System;

namespace Consola
{
    class Program
    {
        static void Main(string[] args)
        {
            //OneA.ExAArray();
            //OneA.ExAList();
            //OneB.ExI();
            //OneB.ExII();
            //OneB.ExII();
            //OneC.ExC();
            //OneC.ExCLINQ();

        }
    }
}
